<template>
  <el-row class="list">
    <el-col :span="24">
      <el-row class="time" type="flex">
        <div class="startTime">
          开始时间 :
          <span v-if="!editFlag">{{ param.startTime | dateFormat }}</span>
          <el-date-picker
            size="small"
            type="datetime"
            placeholder="选择日期时间"
            :default-time="param.startTime"
            v-model="param.startTime"
            value-format="timestamp"
            v-else
          >
          </el-date-picker>
        </div>
        <p class="endTime">
          预计结束时间： {{ getScheduledTime | dateFormat }}
        </p>
        <div class="option">
          <div v-if="!editFlag">
            <el-button
              type="primary"
              size="small"
              icon="el-icon-edit"
              circle
              @click="onEditClick"
            ></el-button>
          </div>
          <div v-else>
            <el-button
              type="success"
              size="small"
              icon="el-icon-check"
              circle
              @click="onCheckClick"
            ></el-button>
            <el-button
              type="danger"
              size="small"
              icon="el-icon-close"
              circle
              @click="onCancelClick"
            ></el-button>
          </div>
        </div>
      </el-row>
    </el-col>
    <el-col>
      <div class="groups">
        <el-scrollbar
          class="scroolbar"
          :wrapStyle="{ margin: 0 }"
          :native="false"
        >
          <el-row type="flex">
            <el-col
              :span="10"
              v-for="(group, index) in param.group"
              :key="index"
            >
              <irrigation-system
                class="group"
                :param="group"
                :ferType="ferType"
                :GroupList="GroupList"
                @irrigation-system-check-click="onEditGroupClick"
                @irrigation-system-delete-click="onDeleteGroupClick(index)"
              ></irrigation-system>
            </el-col>
          </el-row>
        </el-scrollbar>
        <div class="add">
          <el-button
            type="primary"
            size="small"
            icon="el-icon-plus"
            circle
            title="添加灌区"
            @click="onAddClick"
          ></el-button>
        </div>
      </div>
    </el-col>
  </el-row>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import moment from "moment";

import IrrigationSystem from "@/components/back/param/IrrigationSystem.vue";
import { TurnGroupContent } from "@/components/back/param/IrrigationSystem.vue";

import { Group } from "@/app/main/database/model";

import { DatePicker } from "element-ui";
Vue.use(DatePicker);

export interface TurnRecordInterface {
  startTime: number;
  group: TurnGroupContent[];
}

@Component({
  components: {
    IrrigationSystem
  },
  filters: {
    dateFormat: (value, format) => {
      return moment(value).format(format || "YYYY-MM-DD HH:mm:ss");
    }
  }
})
export default class ParamList extends Vue {
  private editFlag = false;
  private ferType = [
    {
      id: 1,
      name: "氮肥"
    },
    {
      id: 2,
      name: "磷肥"
    },
    {
      id: 3,
      name: "钾肥"
    },
    {
      id: 4,
      name: "碳肥"
    }
  ];
  private param: TurnRecordInterface = {
    startTime: 1597998781000,
    group: [
      {
        group: {
          id: 1,
          name: "灌区A",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      },
      {
        group: {
          id: 2,
          name: "灌区B",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      },
      {
        group: {
          id: 3,
          name: "灌区C",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      },
      {
        group: {
          id: 1,
          name: "灌区A",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      },
      {
        group: {
          id: 1,
          name: "灌区A",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      },
      {
        group: {
          id: 1,
          name: "灌区A",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      },
      {
        group: {
          id: 1,
          name: "灌区A",
          user_id: 0,
          create_time: 0,
          crop_id: 1,
          machine_id: 1
        },
        delay: 30,
        runTime: 60,
        type: 2,
        fer: [
          {
            id: 1,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 2,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 3,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          },
          {
            id: 4,
            ferRatio: 1,
            ferWeight: 300,
            ferTime: 30
          }
        ]
      }
    ]
  };
  private cache!: TurnRecordInterface;

  private GroupList: Group[] = [
    {
      id: 1,
      name: "灌区A",
      user_id: 0,
      create_time: 0,
      crop_id: 1,
      machine_id: 1
    },
    {
      id: 2,
      name: "灌区B",
      user_id: 0,
      create_time: 0,
      crop_id: 1,
      machine_id: 1
    },
    {
      id: 3,
      name: "灌区C",
      user_id: 0,
      create_time: 0,
      crop_id: 1,
      machine_id: 1
    }
  ];

  private get getScheduledTime() {
    return (
      this.param.startTime +
      this.param.group.reduce((prev, cur) => {
        let time = 0;
        if (!!prev.runTime) time += (prev.runTime + prev.delay) * 60000;
        //运行时间 延时时间 单位分钟转换为毫秒 *60000
        else if (typeof prev === "number") time += prev;
        if (!!cur.runTime) time += (cur.runTime + cur.delay) * 60000; //运行时间 延时时间 单位分钟转换为毫秒 *60000
        return time;
      })
    );
  }

  private onEditClick() {
    this.editFlag = true;
    this.cache = JSON.parse(JSON.stringify(this.param));
    console.log(this.param);
  }
  private onCancelClick() {
    this.editFlag = false;
    this.param = JSON.parse(JSON.stringify(this.cache));
    console.log(this.param);
  }
  private onCheckClick() {
    this.editFlag = false;
    console.log(this.param);
  }
  private onAddClick() {
    console.log("click");
  }
  private onDeleteClick() {}

  private onEditGroupClick(param: TurnGroupContent) {
    let index = this.param.group.find(item => item.group.id === param.group.id);
    index > -1 && this.param.group.splice(index, 1, param);
    console.log(param, this.param);
  }
  private onDeleteGroupClick(index: number) {
    this.param.group.splice(index, 1);
    console.log(index, this.param);
  }
}
</script>

<style lang="scss" scoped>
.list {
  .time {
    height: 0.3rem;
    width: 100%;

    .startTime {
      padding-right: 0.05rem;
    }
    .option {
      flex: 1;
      text-align: right;
      display: none;
    }

    &:hover {
      .option {
        display: block;
      }
    }
  }

  .groups {
    position: relative;
    .add {
      position: absolute;
      right: 0;
      top: 25%;
      display: none;
    }

    &:hover {
      .add {
        display: block;
      }
    }

    .group {
      margin-right: 0.05rem;
      height: 3.25rem;
    }
  }
}
</style>
