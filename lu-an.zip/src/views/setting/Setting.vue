<template>
  <div>
    Setting
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class Setting extends Vue {}
</script>

<style scoped></style>
