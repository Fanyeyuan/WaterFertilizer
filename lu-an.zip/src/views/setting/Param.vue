<template>
  <div class="list">
    <!-- <el-collapse accordion>
      <el-collapse-item v-for="(param, index) in params" :key="index">
        <template slot="title">
          <div class="listTitle">
            <span
              >编号:<em>{{ param.id }}</em></span
            >
            <span
              >开始时间:<em>{{ param.startTime | dateFormat }}</em></span
            >
            <span
              >预计结束时间:<em>{{ param.startTime | dateFormat }}</em></span
            >
            <span
              >灌区:<em :title="getGroupName(param)">{{
                getGroupName(param)
              }}</em></span
            >
          </div>
        </template>
        <param-list></param-list>
      </el-collapse-item>
    </el-collapse> -->
    <!-- <new-param></new-param> -->
    <param-list></param-list>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

import { Collapse, CollapseItem } from "element-ui";
Vue.use(Collapse);
Vue.use(CollapseItem);

import ParamList from "@/components/back/param/ParamList.vue";
import NewParam from "@/components/back/param/NewParam.vue";

@Component({
  components: {
    ParamList,
    NewParam
  }
})
export default class Param extends Vue {
  private params = [
    {
      id: 1,
      startTime: 1597970827000,
      userId: 0,
      name: "",
      createTime: 0,
      state: 0,
      content: [
        {
          id: 1,
          name: "灌区A",
          sequence: 1,
          irrigationType: 0,
          delay: 0,
          runTime: 30,
          fer: [
            {
              id: 1,
              ferRatio: 1,
              ferWeight: 300,
              ferTime: 30
            },
            {
              id: 2,
              ferRatio: 2,
              ferWeight: 300,
              ferTime: 30
            },
            {
              id: 3,
              ferRatio: 3,
              ferWeight: 300,
              ferTime: 30
            },
            {
              nd: 4,
              ferRatio: 4,
              ferWeight: 300,
              ferTime: 30
            }
          ]
        }
      ],
      remark: ""
    }
  ];

  private getGroupName(param: any) {
    return param.content.map(group => group.name).join(",");
  }
}
</script>

<style lang="scss" scoped>
.list {
  .listTitle {
    width: 100%;
    // height: 80px;
    // line-height: 80px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    span {
      font-size: 12px;
      margin-left: 10px;
      text-align: left;

      em {
        margin-left: 5px;
        color: rgb(7, 107, 114);
        font-size: 16px;
        font-weight: bold;
      }

      &:nth-of-type(4) {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        flex: 0.7;
      }
    }
    .online {
      color: green;
    }
  }
}
</style>
