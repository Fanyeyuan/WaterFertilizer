<template>
  <div class="about" @click="$router.back()">
    <h1>This is an about page</h1>
  </div>
</template>
