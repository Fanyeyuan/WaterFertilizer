import Vue from "vue";
import VueRouter, { RouteConfig } from "vue-router";
import Home from "../views/Home.vue";

Vue.use(VueRouter);

const routes: Array<RouteConfig> = [
  {
    path: "/",
    name: "Home",
    component: Home
  },
  {
    path: "/back",
    name: "Back",
    component: () => import("../views/Back.vue"),
    children: [
      {
        path: "setting",
        name: "Setting",
        component: () =>
          import(/* webpackChunkName: "about" */ "../views/setting/Setting.vue")
      },
      {
        path: "about",
        name: "About",
        component: () =>
          import(/* webpackChunkName: "about" */ "../views/setting/About.vue")
      },
      {
        path: "mapView",
        name: "MapView",
        component: () => import("../views/setting/MapView.vue")
      },
      {
        path: "group",
        name: "Group",
        component: () => import("../views/setting/Group.vue")
      },
      {
        path: "param",
        name: "Param",
        component: () => import("../views/setting/Param.vue")
      }
    ]
  },
  {
    path: "*",
    redirect: "/"
  }
];

const router = new VueRouter({
  routes
});

export default router;
