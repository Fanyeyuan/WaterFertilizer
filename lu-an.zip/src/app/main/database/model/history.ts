interface History {
  /**
   * 主键id 自增
   */
  id: number;

  /**
   * 设备ID
   */
  fac_id: number;

  /**
   * 数据插入时间
   */
  data_time: number;

  /**
   * 要素1
   */
  e1: number;

  /**
   * 要素2
   */
  e2: number;

  /**
   * 要素3
   */
  e3: number;

  /**
   * 要素4
   */
  e4: number;

  /**
   * 要素5
   */
  e5: number;

  /**
   * 要素6
   */
  e6: number;

  /**
   * 要素7
   */
  e7: number;

  /**
   * 要素8
   */
  e8: number;

  /**
   * 要素9
   */
  e9: number;

  /**
   * 要素10
   */
  e10: number;

  /**
   * 要素11
   */
  e11: number;

  /**
   * 要素12
   */
  e12: number;

  /**
   * 要素13
   */
  e13: number;

  /**
   * 要素14
   */
  e14: number;

  /**
   * 要素15
   */
  e15: number;

  /**
   * 要素16
   */
  e16: number;

  /**
   * 继电器1
   */
  JK1: number;

  /**
   * 继电器2
   */
  JK2: number;

  /**
   * 继电器3
   */
  JK3: number;

  /**
   * 继电器4
   */
  JK4: number;

  /**
   * 继电器5
   */
  JK5: number;

  /**
   * 继电器6
   */
  JK6: number;

  /**
   * 继电器7
   */
  JK7: number;

  /**
   * 继电器8
   */
  JK8: number;

  /**
   * 继电器9
   */
  JK9: number;

  /**
   * 继电器10
   */
  JK10: number;

  /**
   * 继电器11
   */
  JK11: number;

  /**
   * 继电器12
   */
  JK12: number;

  /**
   * 继电器13
   */
  JK13: number;

  /**
   * 继电器14
   */
  JK14: number;

  /**
   * 继电器15
   */
  JK15: number;

  /**
   * 继电器16
   */
  JK16: number;

  /**
   * 继电器17
   */
  JK17: number;

  /**
   * 继电器18
   */
  JK18: number;

  /**
   * 继电器19
   */
  JK19: number;

  /**
   * 继电器20
   */
  JK20: number;

  /**
   * 继电器21
   */
  JK21: number;

  /**
   * 继电器22
   */
  JK22: number;

  /**
   * 继电器23
   */
  JK23: number;

  /**
   * 继电器24
   */
  JK24: number;

  /**
   * 继电器25
   */
  JK25: number;

  /**
   * 继电器26
   */
  JK26: number;

  /**
   * 继电器27
   */
  JK27: number;

  /**
   * 继电器28
   */
  JK28: number;

  /**
   * 继电器29
   */
  JK29: number;

  /**
   * 继电器30
   */
  JK30: number;

  /**
   * 继电器31
   */
  JK31: number;

  /**
   * 继电器32
   */
  JK32: number;
}
export default History
