interface Relay {
  /**
   * 主键id 自增
   */
  id: number;

  /**
   * 序号
   */
  indexs: number;

  /**
   * 名称
   */
  name: string;
}
export default Relay
