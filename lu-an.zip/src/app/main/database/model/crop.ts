/**
 * 作物信息
 */
class Crop {
  /**
   * 主键id 自增
   */
  id = 0;

  /**
   * 名称
   */
  name = '';

  /**
   * 备注信息
   */
  remark!: string;
}
export default Crop
